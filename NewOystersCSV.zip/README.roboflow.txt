
NewOysters - v1 OysterDataset1
==============================

This dataset was exported via roboflow.ai on June 9, 2022 at 7:47 PM GMT

It includes 386 images.
Oysters are annotated in Tensorflow Object Detection format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 256x256 (Stretch)

The following augmentation was applied to create 3 versions of each source image:
* Random rotation of between -15 and +15 degrees
* Random shear of between -15° to +15° horizontally and -15° to +15° vertically
* Salt and pepper noise was applied to 5 percent of pixels


